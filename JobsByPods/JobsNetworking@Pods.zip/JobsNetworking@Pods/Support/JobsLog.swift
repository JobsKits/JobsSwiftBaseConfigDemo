//
//  JobsLog.swift
//  JobsNetworking
//
//  Created by Jobs on 31/1/26.
//

import Foundation

public enum JobsLogLevel: String { case debug, info, warn, error }

public struct JobsLogger {
    public typealias Handler = (_ level: JobsLogLevel, _ message: String, _ meta: [String: String]) -> Void

    public var isEnabled: Bool
    public var handler: Handler

    public init(isEnabled: Bool = true, handler: @escaping Handler = { level, message, meta in
        #if DEBUG
        let metaString = meta.map { "\($0.key)=\($0.value)" }.sorted().joined(separator: " ")
        print("[JobsNetworking][\(level.rawValue.uppercased())] \(message) \(metaString)")
        #endif
    }) {
        self.isEnabled = isEnabled
        self.handler = handler
    }

    public func log(_ level: JobsLogLevel, _ message: String, meta: [String: String] = [:]) {
        guard isEnabled else { return }
        handler(level, message, meta)
    }
}
