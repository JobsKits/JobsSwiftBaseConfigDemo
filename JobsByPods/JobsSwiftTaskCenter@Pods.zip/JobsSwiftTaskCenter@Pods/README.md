# JobsSwiftTaskCenter

一个强大、灵活、线程安全的 Swift 任务调度框架，专为 Apple 平台设计。

[![Swift Version](https://img.shields.io/badge/Swift-6.0-orange.svg)](https://swift.org)
[![Platform](https://img.shields.io/badge/Platform-iOS%20%7C%20macOS%20%7C%20tvOS-lightgrey.svg)](https://developer.apple.com)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

## ✨ 特性

- ✅ **完整的生命周期管理** - 支持运行、暂停、恢复、取消等状态
- ✅ **线程安全** - 使用 `NSLock` 保护所有共享状态，标记为 `@unchecked Sendable`
- ✅ **Swift Concurrency 原生支持** - async/await、AsyncSequence 完整集成
- ✅ **多种调度策略** - 一次性、重复、延迟、指定时间等
- ✅ **灵活的任务组合** - 支持任务链接、并发等待等高级功能
- ✅ **性能监控** - 内置性能指标统计
- ✅ **零依赖** - 仅依赖 Foundation 和 JobsSwiftTimer
- ✅ **类型安全** - 完全使用 Swift 类型系统

## 📋 要求

- iOS 13.0+ / macOS 10.15+ / tvOS 13.0+
- Xcode 15.0+
- Swift 6.0+

## 🚀 快速开始

### 基础用法

```swift
import JobsSwiftTaskCenter

// 1. 创建一个简单的延迟任务
let task = JobsPlan.after(.second * 2).do {
    print("2 秒后执行")
}

// 2. 创建重复任务
let repeating = JobsPlan.every(.second, repeatCount: 10).do {
    print("每秒执行一次，共 10 次")
}

// 3. 立即执行，然后重复
let immediate = JobsPlan.every(.second * 5, fireImmediately: true).do {
    print("立即执行第一次，然后每 5 秒执行")
}
```

### 生命周期管理

```swift
let task = JobsPlan.every(.second).do {
    print("运行中...")
}

// 暂停任务
task.suspend()

// 恢复任务
task.resume()

// 取消任务
task.cancel()

// 监听生命周期变化
task.addLifecycleObserver { lifecycle in
    switch lifecycle {
    case .running: print("开始运行")
    case .suspended: print("已暂停")
    case .cancelled: print("已取消")
    case .finished: print("已完成")
    default: break
    }
}
```

### Async/Await 支持

```swift
// 等待任务完成
let task = JobsPlan.after(.second * 2).do {
    print("任务执行")
}
await task.waitUntilFinished()
print("任务已完成")

// 等待指定次数的执行
let repeating = JobsPlan.every(.second).do {
    print("执行中...")
}
await repeating.wait(forExecutions: 5)
print("已执行 5 次")

// 使用 AsyncSequence
for await execution in task.executions() {
    print("执行 #\(execution.count) 在 \(execution.date)")
}
```

### 任务组合器

```swift
// 等待多个任务全部完成
let task1 = JobsPlan.after(.second * 1).do { print("任务 1") }
let task2 = JobsPlan.after(.second * 2).do { print("任务 2") }
let task3 = JobsPlan.after(.second * 3).do { print("任务 3") }

await JobsTask.waitAll([task1, task2, task3])
print("所有任务完成")

// 等待任意一个任务完成
if let first = await JobsTask.waitAny([task1, task2, task3]) {
    print("第一个完成的任务: \(first)")
}

// 批量控制
JobsTask.suspendAll([task1, task2, task3])
JobsTask.resumeAll([task1, task2, task3])
JobsTask.cancelAll([task1, task2, task3])
```

### 性能监控

```swift
let task = JobsPlan.every(.second, repeatCount: 10).do {
    print("执行中...")
}

// 获取性能指标
let metrics = task.metrics
print("总执行次数: \(metrics.totalExecutions)")
print("运行时长: \(metrics.totalDuration) 秒")
if let avgInterval = metrics.averageInterval {
    print("平均间隔: \(avgInterval) 秒")
}
if let rate = metrics.executionRate {
    print("执行频率: \(rate) 次/秒")
}
```

## 📖 核心概念

### JobsPeriod - 时间段

表示一个时间段，提供便捷的时间单位构造：

```swift
JobsPeriod.millisecond  // 1 毫秒
JobsPeriod.second       // 1 秒
JobsPeriod.minute       // 1 分钟
JobsPeriod.hour         // 1 小时
JobsPeriod.day          // 1 天

// 支持数学运算
let period = .second * 5 + .millisecond * 500  // 5.5 秒
```

### JobsPlan - 任务计划

定义任务的执行时间序列：

```swift
// 延迟执行
JobsPlan.after(.second * 2)

// 在指定时间执行
JobsPlan.at(Date().addingTimeInterval(3600))

// 立即执行
JobsPlan.now

// 重复执行
JobsPlan.every(
    .second * 2,           // 间隔
    initialDelay: .second, // 初始延迟（可选）
    repeatCount: 10,       // 重复次数（可选，nil 表示无限）
    fireImmediately: false // 是否立即执行（可选）
)

// 组合计划
let combined = plan1.concat(plan2)
```

### JobsTask - 任务

执行实际工作的对象：

```swift
let task = plan.do {
    // 在主队列执行
    print("执行")
}

let bgTask = plan.do(queue: .global()) {
    // 在后台队列执行
    print("后台执行")
}

let asyncTask = plan.doAsync {
    // 支持 async/await
    try await someAsyncOperation()
}
```

### JobsTaskLifecycle - 生命周期

任务的生命周期状态：

- `.idle` - 空闲（刚创建，未开始）
- `.running` - 运行中
- `.suspended` - 已暂停
- `.cancelled` - 已取消
- `.finished` - 已完成

## 🎯 实际应用场景

### 1. 心跳检测

```swift
let heartbeat = JobsPlan.every(.second * 30).do {
    NetworkManager.shared.sendHeartbeat()
}
```

### 2. 自动保存

```swift
var isDirty = false

let autoSave = JobsPlan.every(.minute).do {
    guard isDirty else { return }
    DataManager.shared.save()
    isDirty = false
}
```

### 3. 定时刷新

```swift
let refresh = JobsPlan.every(.minute * 5).doAsync {
    let data = try await APIClient.shared.fetchData()
    DataStore.shared.update(data)
}
```

### 4. 倒计时

```swift
var remaining = 60

let countdown = JobsPlan.every(.second, repeatCount: 60, fireImmediately: true).do {
    print("剩余: \(remaining) 秒")
    remaining -= 1
}
```

### 5. 重试机制

```swift
let maxRetries = 3
var attempts = 0

let retry = JobsPlan.every(.second * 2, repeatCount: maxRetries).doAsync { task in
    attempts += 1
    do {
        try await performOperation()
        task.cancel()  // 成功后取消
    } catch {
        if attempts >= maxRetries {
            print("重试失败")
        }
    }
}
```

## 🔒 线程安全

JobsSwiftTaskCenter 在设计时充分考虑了线程安全：

1. **锁保护** - 所有共享状态都使用 `NSLock` 保护
2. **Sendable 兼容** - 完全符合 Swift 6 的并发模型
3. **无数据竞争** - 使用 generation token 防止过时回调
4. **安全执行** - Actions 在锁外执行，避免死锁

```swift
// 这样的并发操作是完全安全的
await withTaskGroup(of: Void.self) { group in
    for _ in 0..<10 {
        group.addTask {
            task.addAction { _ in print("安全执行") }
            task.executeNow()
            task.suspend()
            task.resume()
        }
    }
}
```

## 📊 性能特点

- **轻量级** - 最小的内存占用
- **高效** - 基于 DispatchSourceTimer 或 RunLoop
- **可扩展** - 支持数千个并发任务
- **低延迟** - 毫秒级精度

## 🧪 测试

框架包含完整的测试套件，使用 Swift Testing 框架：

```swift
@Test("创建并执行一次性任务")
func testOneShotTask() async throws {
    var executed = false
    let task = JobsPlan.after(.millisecond * 100).do {
        executed = true
    }
    await task.waitUntilFinished()
    #expect(executed == true)
}
```

运行测试：
```bash
swift test
```

## 📝 API 参考

### JobsTask 主要方法

```swift
// 生命周期控制
func suspend()
func resume()
func cancel()
func executeNow()

// Action 管理
@discardableResult
func addAction(_ action: @escaping Action) -> UUID
func removeAction(_ id: UUID)

// 生命周期观察
@discardableResult
func addLifecycleObserver(_ observer: @escaping LifecycleObserver) -> UUID
func removeLifecycleObserver(_ id: UUID)

// 错误处理
@discardableResult
func onError(_ handler: @escaping ErrorHandler) -> Self

// Async/Await
func wait(forExecutions count: Int) async -> Int
func waitForNextExecution() async -> Int
func waitUntilFinished() async
func executeAndWait() async -> Bool

// AsyncSequence
func executions() -> JobsTaskExecutionSequence
```

### JobsTask 静态方法（组合器）

```swift
static func waitAll(_ tasks: [JobsTask]) async
static func waitAny(_ tasks: [JobsTask]) async -> JobsTask?
static func cancelAll(_ tasks: [JobsTask])
static func suspendAll(_ tasks: [JobsTask])
static func resumeAll(_ tasks: [JobsTask])
```

### JobsTask 属性

```swift
var lifecycle: JobsTaskLifecycle { get }
var executionCount: Int { get }
var estimatedNextExecutionDate: Date? { get }
var isRunning: Bool { get }
var isSuspended: Bool { get }
var isCancelled: Bool { get }
var isFinished: Bool { get }
var actionCount: Int { get }
var metrics: JobsTaskMetrics { get }
```

## 🤝 贡献

欢迎贡献！请随时提交 Pull Request。

## 📄 许可证

JobsSwiftTaskCenter 使用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 👤 作者

Jobs - Copyright © 2026

## 🙏 致谢

感谢所有为这个项目做出贡献的开发者。

---

**注意**: 本框架需要 JobsSwiftTimer 作为底层定时器实现。
